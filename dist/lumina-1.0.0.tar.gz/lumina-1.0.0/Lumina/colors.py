from random import randrange

def color_palette():
    rand_color = (randrange(255), randrange(255), randrange(255))
    return rand_color

